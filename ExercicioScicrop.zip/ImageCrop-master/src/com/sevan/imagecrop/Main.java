package com.sevan.imagecrop;

public class Main {

    public static void main(String[] args) {
        // write your code here
        String sourcePath = "C:/Windows/Temp/portrait.png";
        String descPath = "C:/Windows/Temp/crop.jpg";
        ImageCropUtil.ImageCropCenterSquare(sourcePath, descPath);
    }
}
